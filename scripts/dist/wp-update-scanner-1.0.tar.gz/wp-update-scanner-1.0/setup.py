from distutils.core import setup

setup(name='wp-update-scanner', version='1.0', author='Steve Whitmore',
      author_email='steve.whitmore@protonmail.com',
      url='https://stevewhitmore.github.io',)